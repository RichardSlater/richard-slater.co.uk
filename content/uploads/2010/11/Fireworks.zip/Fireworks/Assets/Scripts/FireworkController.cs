using UnityEngine;
using System.Collections;

public class FireworkController : MonoBehaviour {

	private ConstantForce m_constantForce;
	private ParticleEmitter m_fireworkParticles;
	private Vector3 m_startPosition;
	
	public ParticleEmitter fireworkParticleEmitter;
	public int targetHeight = 50;
	
	void OnCollisionEnter(Collision collision)
	{
		TriggerExplosion();
	}
	
	// Use this for initialization
	void Start () {
		m_constantForce = GetComponent<ConstantForce>();
		m_startPosition = transform.position;
		m_constantForce.enabled = true;
	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.y > targetHeight)
			TriggerExplosion();
	}
	
	private void TriggerExplosion()
	{
		m_constantForce.relativeForce = new Vector3(Random.Range(-0.1f, 0.1f), Random.Range(0.25f, 1.25f), Random.Range(-0.1f, 0.1f));
		targetHeight += Random.Range(-5, 5);
		
		if (targetHeight < 25)
			targetHeight = 100;
		
		if (fireworkParticleEmitter != null)
		{
			m_fireworkParticles = (ParticleEmitter)Instantiate(fireworkParticleEmitter, transform.position, Quaternion.identity);
			m_fireworkParticles.emit = true;
		}

		transform.position = m_startPosition;
	}
}
